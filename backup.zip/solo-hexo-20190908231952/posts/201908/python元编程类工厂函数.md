title: 《python元编程》类工厂函数
date: '2019-08-09 11:34:11'
updated: '2019-08-09 11:41:57'
tags: [python, python进阶]
permalink: /articles/2019/08/09/1565321651236.html
---
python类工厂函数和元类