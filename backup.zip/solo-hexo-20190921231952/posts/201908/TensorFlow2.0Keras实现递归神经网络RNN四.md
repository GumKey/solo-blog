title: 《TensorFlow2.0》Keras实现递归神经网络RNN（四）
date: '2019-08-11 20:39:46'
updated: '2019-08-21 17:41:58'
tags: [python, TensorFlow]
permalink: /articles/2019/08/11/1565527186252.html
---
![](https://img.hacpai.com/bing/20190819.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 
> <font color="red">**导读**</font>：
1、递归神经网络代表循环网络的另一个扩展，它被构造为深的树状结构而不 是 RNN 的链状结构，因此是不同类型的计算图。
2、递归网络已成功地应用于输入是树状结构的神经网络，如自然语言处理和计算机视觉。