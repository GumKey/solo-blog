title: golang指针（五）
date: '2019-08-01 23:32:37'
updated: '2019-08-08 14:21:10'
tags: [golang, go进阶]
permalink: /articles/2019/08/01/1564673557831.html
---
### 指针


### 析构函数