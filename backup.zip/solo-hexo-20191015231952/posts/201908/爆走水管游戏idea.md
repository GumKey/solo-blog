title: 《爆走水管》游戏idea
date: '2019-08-29 19:46:38'
updated: '2019-08-29 19:46:38'
tags: [待分类]
permalink: /articles/2019/08/29/1567079198169.html
---
![a5c27d1ed21b0ef40c56771205df5adf80cb3ee4.jpeg](https://img.hacpai.com/file/2019/08/a5c27d1ed21b0ef40c56771205df5adf80cb3ee4-469bfe97.jpeg)

奇思异想：
一款在线对战游戏，类似经典吃吃吃