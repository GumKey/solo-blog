title: 《python函数》递归进阶
date: '2019-08-09 10:47:01'
updated: '2019-08-09 11:43:09'
tags: [python, python进阶]
permalink: /articles/2019/08/09/1565318821075.html
---
> 用python写了一个爬虫，中间使用的递归函数，但是没有数据返回，调试后发现是自己想当然了>

首先我们写一个简单的递归代码