title: golang的类（四）
date: '2019-08-01 23:30:46'
updated: '2019-08-08 14:21:18'
tags: [golang, go入门]
permalink: /articles/2019/08/01/1564673446852.html
---
### 类声明


```
type User struct {
    Name  string
    Sex string
    Age  int
}
```


### 类方法声明
```
func (user *User) publish() {
    fmt.Println("poem publish")
}
```
或者
```
func (user User) publish() {
    fmt.Println("poem publish")
}
```