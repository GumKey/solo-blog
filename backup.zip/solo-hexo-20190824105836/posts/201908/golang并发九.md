title: golang并发（九）
date: '2019-08-02 23:31:31'
updated: '2019-08-23 18:20:16'
tags: [golang, go进阶]
permalink: /articles/2019/08/02/1564759890939.html
---
### <font color="#006666">一、Goroutine</font>
> * go中实现并发的主要方法是goroutine，官方介绍goroutine 是轻量级线程，现有的术语—线程、协程、进程等等均无法准确传达它的含义，为了更好的理解goroutine，你可以称它为Go程
* 你也可以使用其他传统方式来实现go的同步并发（进程，线程，协程），异步并发（io异步），但建议使用goroutine，因为他很方便。

#### 1、goroutine语法：
```
go 函数名( 参数列表 )
```
#### 1、实例：
```
package main  
  
import (  
        "fmt"  
        "time"  
)  
  
func say(s string) {  
        for i := 0; i < 5; i++ {  
                time.Sleep(100 * time.Millisecond)  
                fmt.Println(s)  
        }  
}  
  
func main() {  
        go say("world")  
        say("hello")  
}
```
### <font color="#006666">二、channel</font>

### <font color="#006666">二、sync.WaitGroup</font>