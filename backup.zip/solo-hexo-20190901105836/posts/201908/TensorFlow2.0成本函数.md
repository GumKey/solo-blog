title: 《TensorFlow2.0》成本函数
date: '2019-08-27 22:40:41'
updated: '2019-08-27 22:40:41'
tags: [待分类]
permalink: /articles/2019/08/27/1566916841041.html
---
<font color="red">**导读：**</font>成本函数􏰍（cost function）􏰎也叫损失函数（􏰍loss function􏰎􏰊），用来定义模型与观测值的误差􏰋。有哪些成本函数？他们的算法推论是怎样的？各自应用于什么场景？

### <font color="#006666">一、基本算法</font>

#### 1、残差、方差

