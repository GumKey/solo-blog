title: 《TensorFlow2.0》低阶api入门
date: '2019-08-02 23:41:46'
updated: '2019-08-08 14:20:38'
tags: [python, TensorFlow]
permalink: /articles/2019/08/02/1564760506381.html
---
> 让我们愉快的做一个tf（tensorflow）boy吧！

### <font color="red">一、tf术语</font>
1、张量（tensor）：常数是0维度的张量，向量是1维度的张量，矩阵是二维度的张量，以及还有多维度的张量。
`方法：tf.Variable，tf.constant，tf.placeholder，tf.SparseTensor，除了 tf.Variable以外，张量的值是不变的`
```
mammal = tf.Variable("Elephant", tf.string)
ignition = tf.Variable(451, tf.int16)
floating = tf.Variable(3.14159265359, tf.float64)
its_complicated = tf.Variable(12.3 - 4.85j, tf.complex64)
```
2、常量（constant）：不可更改的张量
`方法：tf.constant`
```
constant = tf.constant([1, 2, 3])
```
3、占位符：没有传入具体值的张量，可以理解函数中的形参
`方法： tf.placeholder`
```
x = tf.placeholder(tf.float32, shape=[3])
y = tf.square(x)

with tf.Session() as sess:
  print(sess.run(y, {x: [1.0, 2.0, 3.0]})) # => "[1.0, 4.0, 9.0]"
  print(sess.run(y, {x: [0.0, 0.0, 5.0]})) # => "[0.0, 0.0, 25.0]"
```
4、操作（op）：
`方法：tf.Operation`
```
调用 `tf.constant(42.0)` 可创建单个 tf.Operation，该操作可以生成值 `42.0`，将该值添加到默认图中，并返回表示常量值的 tf.Tensor。
```
5、图（graph）：
`方法：tf.Graph`
```
大多数 TensorFlow 程序都以数据流图构建阶段开始。在此阶段，您会调用 TensorFlow API 函数，这些函数可构建新的 tf.Operation（节点）和 tf.Tensor（边）对象并将它们添加到 tf.Graph 实例中。TensorFlow 提供了一个**默认图**，此图是同一上下文中的所有 API 函数的明确参数。
```

6、会话（session）：在tf中，先搭建好计算图，然后再启动session，运行定义好的图。
`方法：tf.Session()`
```
x = tf.constant([[37.0, -23.0], [1.0, 4.0]])
w = tf.Variable(tf.random_uniform([2, 2]))
y = tf.matmul(x, w)
output = tf.nn.softmax(y)
init_op = w.initializer

with tf.Session() as sess:
  sess.run(init_op)
  print(sess.run(output))
  y_val, output_val = sess.run([y, output])
```
### <font color="red">一、第一个程序Hello World</font>