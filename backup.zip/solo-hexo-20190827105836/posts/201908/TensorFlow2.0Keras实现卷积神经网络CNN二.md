title: 《TensorFlow2.0》Keras实现卷积神经网络CNN（二）
date: '2019-08-11 20:34:35'
updated: '2019-08-21 17:30:02'
tags: [python, TensorFlow]
permalink: /articles/2019/08/11/1565526875441.html
---
![](https://img.hacpai.com/bing/20180420.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 
> <font color="red">**导读**</font>：什么是卷积运算？池化？为什么要使用CNN？怎么用keras实现？本文试图回答上述这些问题。

### <font color="#006666">一、什么是循环神经网络</font>
#### 1、什么是CNN：
```
卷积网络是指那些至少在网络的一层中使用卷积运算来 替代一般的矩阵乘法运算的神经网络。
```

#### 2、CNN中的特殊数学运算：
* **卷积运算**
什么是卷积

* **池化**
什么是池化

