title: golang入门（一）
date: '2019-07-25 16:19:12'
updated: '2019-08-08 14:21:38'
tags: [golang, go入门]
permalink: /articles/2019/07/25/1564042752679.html
---
> 域名备案今天过了，刚好最近入手golang，遂决定第一篇blog就给go了，顺便把刚学的知识做个记录，but my lover is still python

###  <font color=#006666>一、安装GO</font>
```
使用go version 命令查看版本：go version go1.12.7 darwin/amd64（Mac）
```

#### 1.  安装：
* 创建目录：
```
mkdir -f /usr/local/go
mkdir -f /usr/local/gopath/bin
mkdir -f /usr/local/gopath/pkg
mkdir -f /usr/local/gopath/src
```
> src是我们的工程目录，以后的项目都在src下面，安装的第三方包也会出现在src/github.com这个文件夹

* 下载go源码包：https://studygolang.com/dl/golang/go1.12.7.src.tar.gz
* 将源码包解压到/usr/local/go目录下
#### 2、环境配置：
Mac下，打开.bash_profile，将下面代码添加到文件，其他系统自行查看环境变量添加方式
```
# go环境配置
export GOROOT=/usr/local/go
export GOARCH=amd64
export GOOS=darwin
export GOPATH=/usr/local/gopath
export GOBIN=$GOPATH/bin
export PATH=$PATH:$GOPATH/bin
```
环境配置好，输入source .bash_profile配置立即生效，下面就可以愉快的玩耍啦！



### <font color=#006666>二、第一个go程序</font>
第一个go程序当然是经典的HelloWorld了，话不多说，直接上代码

hello.go文件
```
package main  
  
import "fmt"  
  
func main() {  
    fmt.Println("Hello, World!")  
}
```
go run hello.go（文件名），执行以上代码：
```
$ go run hello.go 
Hello, World!
```
或者使用 go build 命令来生成二进制文件
```
$ go build hello.go 
$ ls
hello    hello.go
$ ./hello 
Hello, World!
```

`第一篇go入门就到这里了，博客中会介绍Gin框架，可以通过分类或搜索找到它，一个go的web框架，并用它来搭建一个博客，会讲述后端人员如何优雅的搭建前端页面，希望对你有帮助！
`
