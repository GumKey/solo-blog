title: golang基础语法（二）
date: '2019-08-01 23:28:14'
updated: '2019-08-08 14:21:31'
tags: [golang, go入门]
permalink: /articles/2019/08/01/1564673293975.html
---
> 上一章介绍了golang的安装，及第一个程序helloworld
本章主要讲一下go的基础语法

### <font color=#006666>一、IDE</font>
```
个人使用GoLand，你写完程序，缺少的包会自动导入，依然是jb公司的产品，其他IDE可以自行搜索了解
```

### <font color=#006666>二、语言结构</font>
golang中，一般包括以下三部分：
```
 // 包声明，同一个文件夹下声明都为文件夹的名称
package model        
              
// 导入模块，可以是第三方包，也可以是自定义的 
import "fmt"                           

// 变量，程序或其他操作的声明及逻辑处理
var u int                                 
func User(*u) {                          
    fmt.Println(u)  
}
```
### <font color=#006666>三、基础语法</font>
> 基础语法是官方文档及自己开发中所体会的记录，会长期更新，如遇到问题，来这里看一看，希望可以帮助到你。

```
1. 对外需要导入的包或引用，变量的首字母需要打写（typescript中，使用export表示部分可以被外部引用）如：func User(){ }，User首字母大写。

2.go git go get github.com/go-sql-driver/mysql（mysql连接包），来安装第三包，安装的包会出现在安装时候创建的gopath/src下
```
