title: golang并发（九）
date: '2019-08-02 23:31:31'
updated: '2019-08-24 13:51:59'
tags: [golang, go进阶]
permalink: /articles/2019/08/02/1564759890939.html
---
> <font color="red">**导读：**</font>本篇文章主要说明一下几个问题：
1、 什么是并发，什么是并行？
2、golang 中怎么实现并发？什么是goroutine？
3、go如何实现传统的同步并发（多进程，多线程，协程）
3、怎么实现所有并发任务（子程序）结束后，主程序结束。

### <font color="#006666">一、go并发</font>
#### 1、并发和并行
在了解go并发之前，我们简单的理解一下并发和并行：
> * 并行：一条四通道的高速公路，通过某一个违章拍照点，同时最多并行4辆车。即并行和你的通道有关，在计算器中并行和你的cpu核数有关。
* 并发：还是那条四通道的高速公路，但由于车速很快，在很短的时间里（几乎感受不到间隔），通过违章拍摄点，并发车辆可以达到20辆（大于4辆以上）。

#### 2、使用goroutine实现并发
#### 1.1什么是goroutine：
> * go中实现并发的主要方法是goroutine，官方介绍goroutine 是轻量级线程。
* 现有的术语—线程、协程、进程等等均无法准确传达它的含义
* 为了更好的理解goroutine，你可以称它为Go程。
* goroutine 的调度是由 Golang 运行时进行管理的。

#### 1.2如何实现
方法：
```
go 函数名( 参数列表 )
```
实例：
```
package main  
  
import (  
        "fmt"  
        "time"  
)  
  
func say(s string) {  
        for i := 0; i < 5; i++ {  
                time.Sleep(100 * time.Millisecond)  
                fmt.Println(s)  
        }  
}  

func sayLong(s string) {  
        for i := 0; i < 5; i++ {  
                time.Sleep(500 * time.Millisecond)  
                fmt.Println(s)  
        }  
}  
  
func main() {  
        go say("world")  
        sayLong("hello")  
}
```
#### 3、拓展
1、通过前面的阅读，相信你也了解了并发和并行的概念，及go实现并发的方式，至于goroutine运行机制你可以查找一些文档进行深入理解。
2、你可以调用 runtime.GOMAXPROCS() 用来设置可以并行计算的CPU核数的最大值；调用 runtime.Goexit() 将立即终止当前 goroutine 执⾏。
3、当go主程序结束时候，其他子程序也会结束。下面会介绍两种方式channel和sync.WaitGroup来实现传统并发方式中的“守护进程/线程”。

### <font color="#006666">二、channel</font>
```
package main  
  
import "fmt"  
  
func sum(s []int, c chan int) {  
        sum := 0  
        for _, v := range s {  
                sum += v  
        }  
        c <- sum // 把 sum 发送到通道 c  
}  
  
func main() {  
        s := []int{7, 2, 8, -9, 4, 0}  
  
        c := make(chan int)  
        go sum(s[:len(s)/2], c)  
        go sum(s[len(s)/2:], c)  
        x, y := <-c, <-c // 从通道 c 中接收  
  
        fmt.Println(x, y, x+y)  
}
```

### <font color="#006666">二、sync.WaitGroup</font>
```
package main

import (
	"fmt"
	"golang.org/x/sys/unix"
	"os"
	"sync"
	"time"
)

func say(s string, n int, wg *sync.WaitGroup) {
	for i := 0; i < 3; i++ {
		//fmt.Println("开始")
		fmt.Printf("开始：%s：%d：%d\n", s,os.Getpid(), unix.Getgid())
		//fmt.Printf("%d\n", os.Getpid())
		time.Sleep(time.Duration(n))
		fmt.Println(s)
	}
	//wg.Done()
	defer wg.Done()
}

func main() {
	var wg sync.WaitGroup
	wg.Add(1)
	go say("world", 100000000, &wg)
	wg.Add(1)
	go say("hello", 1500000000, &wg)

	wg.Wait() // 等待
	fmt.Println("over")
}
```