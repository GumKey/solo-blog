title: 《TensorFlow2.0》Keras高阶api入门（一）
date: '2019-08-04 23:04:28'
updated: '2019-08-18 13:24:05'
tags: [python, TensorFlow]
permalink: /articles/2019/08/04/1564931068743.html
---
![](https://img.hacpai.com/bing/20181215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


Keras 是一个用于构建和训练深度学习模型的高阶 API。它可用于快速设计原型、高级研究和生产，具有以下三个主要优势：

> * *方便用户使用*  
    `Keras 具有针对常见用例做出优化的简单而一致的界面。它可针对用户错误提供切实可行的清晰反馈。`
* *模块化和可组合*  
    `将可配置的构造块连接在一起就可以构建 Keras 模型，并且几乎不受限制。`
* *易于扩展*  
    `可以编写自定义构造块以表达新的研究创意，并且可以创建新层、损失函数并开发先进的模型。`

*<font color="red">**摘自**：Tensorflow2.0官方文档，更多Keras详细可查看[官方文档](https://keras.io/zh/)，本篇文章意在使读者对tf2.0中运行Keras有一个快速的认知，如果你已经很清楚了，可以跳过本篇</font>*

### <font color="#006666">一、用Keras构建你的模型</font>
1、keras构建模型主要有两种方式：**序贯模型**和**函数式模型**，这两种模型的代码相对简单，可以去[tensorflow2.0官网](https://tensorflow.google.cn/guide/keras)查阅，建议运行一遍。
2、假设你已经了解上面说的两种keras模型构建方式，但还是存在一定的疑虑，👇是个人的一点理解：

* 深度学习模型采用了和神经网络相似的分层结构，系统由包括输入层、<font color="red">**隐层（多层）**</font>、输出层组成的多层网络。
* 深度学习模型采用了和神经网络不通的训练机制，传统神经网络中，采用BP的训练方式（对仅含几层的神经网络已经很不理想），而深度学习整体上是一个<font color="red">**layer-wise的训练机制**</font>。
* 2006年，hinton提出了在非监督数据上建立多层神经网络的一个有效方法，1、首先<font color="red">**逐层构建单层神经元**</font>，这在keras的两种模型构建方式中已有体现，2、所有层训练完后，使用<font color="red">**wake-sleep算法**</font>进行调优。。
* 你想使用keras实现一个最简单的线性回归，你只要加一层全连接层，使用<font color="red">**默认激活函数liner**</font>，下面是一些常用的激活函数：

	```
	 softmax: 在多分类中常用的激活函数，是基于逻辑回归的。
	 Softplus：softplus(x)=log(1+e^x)，近似生物神经激活函数，最近出现的。
	 Relu：近似生物神经激活函数，最近出现的。
	 tanh：双曲正切激活函数，也是很常用的。
	 sigmoid：S型曲线激活函数，最常用的。
	 hard_sigmoid：基于S型激活函数。
	 linear：线性激活函数，最简单的，不设置激活函数时默认的。
	```
* 第一层中必须设置input_shape，其他层会自动识别，例：在多分类中，你的特征为[8,3,0...5,7]长度300个，训练数据有60000条，**input_shape=(300,)**，即你的特征为一阶的张量。
* keras中卷积层，池化层的设置和全连接层Dense的设置一样简单，前提是你知道你参数的意义。
* 如果想加深了解高阶api背后运行的机制和算法，网上有很多文档，建议<font color="red">**手推**</font>一次你所用的算法，或者用低阶api来实现，<font color="red">**numpy**</font>也是一个不错的选择，而且已经有人实现并且开源了。

### <font color="#006666">二、Keras中的网络层</font>
如果在上面运行了keras的两种模型构建方式，那你应该知道keras构建模型的过程，包括
1、实例化tf.keras.Sequential，函数式api中是tf.keras.Model
2、添加多个网络层 [`tf.keras.layers`](https://tensorflow.google.cn/api_docs/python/tf/keras/layers)，它们具有一些相同的构造函数参数：

* `activation`：设置层的激活函数。此参数由内置函数的名称指定，或指定为可调用对象。默认情况下，系统不会应用任何激活函数。
* `kernel_initializer` 和 `bias_initializer`：创建层权重（核和偏差）的初始化方案。此参数是一个名称或可调用对象，默认为 `"Glorot uniform"` 初始化器。
* `kernel_regularizer` 和 `bias_regularizer`：应用层权重（核和偏差）的正则化方案，例如 L1 或 L2 正则化。默认情况下，系统不会应用正则化函数。

3、用compile配置模型的学习流程，配置包括以下三个参数。

* `optimizer`：此对象会指定训练过程。从 [`tf.train`](https://tensorflow.google.cn/api_docs/python/tf/train) 模块向其传递优化器实例，例如：随机梯度下降优化算法。
* `loss`：要在优化期间最小化的函数。常见选择包括均方误差 ，损失函数由名称或通过从 [`tf.keras.losses`](https://tensorflow.google.cn/api_docs/python/tf/keras/losses) 模块传递可调用对象来指定。
* `metrics`：用于监控训练。它们是 [`tf.keras.metrics`](https://tensorflow.google.cn/api_docs/python/tf/keras/metrics) 模块中的字符串名称或可调用对象。

### <font color="#006666">三、实现fashion-mnist图片分类</font>
fashion-mnist数据机[下载地址](https://pan.baidu.com/s/1jLWa2j02jEpJZnrWtkX84A)，你可以使用它直接替换你传统mnist数据集。
1、读取数据
```
import os
import gzip
import numpy as np
def load_mnist(path, kind='train'):

    """Load MNIST data from `path`"""
    labels_path = os.path.join(path,
                               '%s-labels-idx1-ubyte.gz'
                               % kind)
    images_path = os.path.join(path,
                               '%s-images-idx3-ubyte.gz'
                               % kind)

    with gzip.open(labels_path, 'rb') as lbpath:
        labels = np.frombuffer(lbpath.read(), dtype=np.uint8,
                               offset=8)

    with gzip.open(images_path, 'rb') as imgpath:
        images = np.frombuffer(imgpath.read(), dtype=np.uint8,
                               offset=16).reshape(len(labels), 784)

    return images, labels
```

```
# 每个图像都映射到一个标签。由于类别名称不包含在数据集中,因此把他们存储在这里以便在绘制图像时使用:
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']
# 读取训练集
train_images, train_labels = load_mnist("fashion-mnist")
train_images = train_images.reshape(60000, 28,28)
# fashion-mnist图片展示
plt.figure(figsize=(10,10))
for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(train_images[i], cmap=plt.cm.binary)
    plt.xlabel(class_names[train_labels[i]])
plt.show()
```
![fm.png](https://img.hacpai.com/file/2019/08/fm-cdbaf6b0.png)
2、构建模型
```
from tensorflow.keras import Sequential, layers
import tensorflow as tf
# 添加卷积层，全连接层，设置激活函数relu， softmax
model = Sequential()
model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.Flatten())
model.add(layers.Dense(64, activation='relu'))
model.add(layers.Dense(10, activation='softmax'))
# 编译模型，设置优化函数及成本函数
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# 对输入特征reshpae，因为我们上面input_shape是(28, 28, 1)
train_images_2d = train_images.reshape(60000, 28, 28, 1)
# 训练模型
model.fit(train_images_2d, train_labels, epochs=5)
```
3、评估
```
# 读取测试集进行预测，评估
test_images, test_labels = load_mnist("fashion-mnist","t10k")
test_images = test_images.reshape(10000, 28,28)
# 评估
test_loss, test_acc = model.evaluate(test_images, test_labels)
print('Test accuracy:', test_acc)
```

