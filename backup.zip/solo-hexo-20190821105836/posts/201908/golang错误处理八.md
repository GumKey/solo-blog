title: golang错误处理（八）
date: '2019-08-02 23:28:36'
updated: '2019-08-08 14:20:51'
tags: [golang, go进阶]
permalink: /articles/2019/08/02/1564759716911.html
---
q