title: 《TensorFlow2.0》Keras实现递归神经网络RNN（四）
date: '2019-08-11 20:39:46'
updated: '2019-08-11 20:40:18'
tags: [python, TensorFlow]
permalink: /articles/2019/08/11/1565527186252.html
---
《TensorFlow2.0》Keras实现递归神经网络RNN（四）