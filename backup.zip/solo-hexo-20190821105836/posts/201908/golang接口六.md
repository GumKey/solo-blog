title: golang接口（六）
date: '2019-08-01 23:33:57'
updated: '2019-08-08 14:21:03'
tags: [golang, go进阶]
permalink: /articles/2019/08/01/1564673637582.html
---
### <font color=#006666>一、接口定义</font>

```
/* 定义接口 */  
type interface_name interface {  
   method_name1 [return_type]  
   method_name2 [return_type]  
   method_name3 [return_type]  
   ...  
   method_namen [return_type]  
}  
  
/* 定义结构体 */  
type struct_name struct {  
   /* variables */  
}  
  
/* 实现接口方法 */  
func (struct_name_variable struct_name) method_name1() [return_type] {  
   /* 方法实现 */  
}  
...  
func (struct_name_variable struct_name) method_namen() [return_type] {  
   /* 方法实现*/  
}
```

### <font color=#006666>二、实例</font>

```
package main  
  
import (  
    "fmt"  
)  
  
type Phone interface {  
    call()  
}  
  
type NokiaPhone struct {  
}  
  
func (nokiaPhone NokiaPhone) call() {  
    fmt.Println("I am Nokia, I can call you!")  
}  
  
type IPhone struct {  
}  
  
func (iPhone IPhone) call() {  
    fmt.Println("I am iPhone, I can call you!")  
}  
  
func main() {  
    var phone Phone  
  
    phone = new(NokiaPhone)  
    phone.call()  
  
    phone = new(IPhone)  
    phone.call()  
  
}
```

