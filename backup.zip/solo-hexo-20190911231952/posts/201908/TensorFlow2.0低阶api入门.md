title: 《TensorFlow2.0》低阶api入门
date: '2019-08-02 23:41:46'
updated: '2019-08-12 09:39:48'
tags: [python, TensorFlow]
permalink: /articles/2019/08/02/1564760506381.html
---
![](https://img.hacpai.com/bing/20190713.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


> TensorFlow2.0已经支持keras了，也就是说可以直接在tf2.0中使用keras的api了，Keras 是一个用 Python 编写的高级神经网络 API，它能够以TensorFlow，CNTK或者Theano作为后端运行，所以还是写了一篇tf的低阶api入门，来了解tf中进行深度学习的流程和原理，现在让我们愉快的做一个tf（tensorflow）boy吧！

### <font color="#006666">一、TF中的一些概念</font>
#### 1、张量（Tensor）：

* 一般张量：
	`方法：tf.Variable`
	```
	mammal = tf.Variable("Elephant", tf.string)
	```
* 常量
	`方法：tf.constant`
	```
	# 定义常量constant
	constant = tf.constant([1, 2, 3])
	```
* 占位符
	`方法： tf.placeholder`
	```
	x = tf.placeholder(tf.float32, shape=[3])
	y = tf.square(x)
	
	with tf.Session() as sess:
	  print(sess.run(y, {x: [1.0, 2.0, 3.0]})) # => "[1.0, 4.0, 9.0]"
	  print(sess.run(y, {x: [0.0, 0.0, 5.0]})) # => "[0.0, 0.0, 25.0]"
	```
* 稀疏张量
	`方法：tf.SparseTensor`
	```
	SparseTensor(indices=[[0, 0], [1, 2]], values=[1, 2], dense_shape=[3, 4])
	```


#### 2、操作（op）：
`方法：tf.Operation`
```
调用 `tf.constant(42.0)` 可创建单个 tf.Operation，该操作可以生成值 `42.0`，将该值添加到默认图中，并返回表示常量值的 tf.Tensor。
```
#### 3、图（graph）：
`方法：tf.Graph`
```
大多数 TensorFlow 程序都以数据流图构建阶段开始。在此阶段，您会调用 TensorFlow API 函数，这些函数可构建新的 tf.Operation（节点）和 tf.Tensor（边）对象并将它们添加到 tf.Graph 实例中。TensorFlow 提供了一个**默认图**，此图是同一上下文中的所有 API 函数的明确参数。
```
#### 4、会话（session）：在tf中，先搭建好计算图，然后再启动session，运行定义好的图。
`方法：tf.Session()`
```
x = tf.constant([[37.0, -23.0], [1.0, 4.0]])
w = tf.Variable(tf.random_uniform([2, 2]))
y = tf.matmul(x, w)
output = tf.nn.softmax(y)
init_op = w.initializer

with tf.Session() as sess:
  sess.run(init_op)
  print(sess.run(output))
  y_val, output_val = sess.run([y, output])
```
### <font color="#006666">二、第一个程序Hello World</font>
博主使用的是tensorflow最新版本为tf2.0-beat1版本，tf1.x版本中有些特效在2.0中已经移除，可以使用如下方法在2.0中运行1.x版本的tensoflow。
```
# tf2.0 版本
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
# tf 1.x版本
# import tensorflow as tf


# 创建常量
hello_op = tf.constant('Hello,world!')
# 创建会话运行
with tf.Session() as sess:
    print(sess.run(hello_op))
```
### <font color="#006666">三、线性回归</font>
使用简单的线性回归模型，熟悉tf的训练模式，下面代码是一个二元一次线性模型

```
# tf2.0 版本
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
# tf 1.x版本
# import tensorflow as tf
import numpy as np

# 使用 NumPy 生成假数据(phony data), 总共 100 个点.
x_data = np.float32(np.random.rand(2, 100)) # 随机输入
y_data = np.dot([0.100, 0.200], x_data) + 0.300

# 构造一个线性模型
b = tf.Variable(tf.zeros([1]))
W = tf.Variable(tf.random_uniform([1, 2], -1.0, 1.0))
y = tf.matmul(W, x_data) + b

# 损失函数：tf手写最小化方差
loss = tf.reduce_mean(tf.square(y - y_data))
# 优化器：tf自带的随机梯度下降算法
optimizer = tf.train.GradientDescentOptimizer(0.5)
# 训练目的：让loss最小
train = optimizer.minimize(loss)

# 运行模型前先要初始化所有变量
init = tf.initialize_all_variables()

# 启动图 (graph)
sess = tf.Session()
sess.run(init)

# 在启动的图中，进行训练，拟合平面
for step in range(0, 201):
    sess.run(train)
    if step % 20 == 0:
        print(step, sess.run(W), sess.run(b))

# 得到最佳拟合结果 W: [[0.100  0.200]], b: [0.300]
```
我们通过可视化图形，来直观的看本次训练的结果如何：

```
y_predict = sess.run(tf.matmul(W, x_data) + b)
# 预测结果y_predict与实际结果y_data，基本符合y=x的正比例函数
plt.scatter(y_data,y_predict[0])
plt.show()
```
从图像可以看出，预测结果与实际结果基本符合y=x的正比例函数，不过这是用训练集数据进行预测，一般情况下需要一个测试集迭代模型，一个验证集进行验证，此处只为演示tensorflow开发流程。
![预测结果.png](https://img.hacpai.com/file/2019/08/预测结果-313addca.png)


