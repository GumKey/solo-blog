title: 《TensorFlow2.0》Keras实现循环神经网络RNN（二）
date: '2019-08-11 20:34:35'
updated: '2019-08-11 20:35:54'
tags: [python, TensorFlow]
permalink: /articles/2019/08/11/1565526875441.html
---
《TensorFlow2.0》Keras_api实现循环神经网络RNN（二）