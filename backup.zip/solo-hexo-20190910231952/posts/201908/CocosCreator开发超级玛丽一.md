title: 《Cocos Creator》开发超级玛丽（一）
date: '2019-08-07 23:48:34'
updated: '2019-08-08 14:20:19'
tags: [cocos, 超级玛丽]
permalink: /articles/2019/08/07/1565192914735.html
---
cocos creator 基础教程可以去官方看，因为官方有教学视频，有交互工具 操作方式