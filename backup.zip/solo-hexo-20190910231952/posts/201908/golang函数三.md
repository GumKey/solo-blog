title: golang函数（三）
date: '2019-08-01 23:28:50'
updated: '2019-08-08 14:21:24'
tags: [golang, go入门]
permalink: /articles/2019/08/01/1564673330576.html
---
> <font color="blue">**导读**</font>：本章一，二部分引用来自[菜鸟教程](https://www.runoob.com/go/go-functions.html/)，第三部分函数参数，讲解<font color="red">值传递</font>和<font color="red">指针传递</font>的区别与应用

###  <font color=#006666>一、函数定义</font>
Go 语言函数定义格式如下：
```
func function_name( [parameter list] ) [return_types] {
   函数体
}
```
实例
```
/* 函数返回两个数的最大值 */  
func max(num1, num2 int) int {  
   /* 声明局部变量 */  
   var result int  
  
   if (num1 > num2) {  
      result = num1  
   } else {  
      result = num2  
   }  
   return result   
}
```

###  <font color=#006666>二、函数调用</font>
调用函数，向函数传递参数，并返回值，例如：
```
package main  
  
import "fmt"  
  
func main() {  
   /* 定义局部变量 */  
   var a int = 100  
   var b int = 200  
   var ret int  
  
   /* 调用函数并返回最大值 */  
   ret = max(a, b)  
  
   fmt.Printf( "最大值是 : %d\n", ret )  
}  
  
/* 函数返回两个数的最大值 */  
func max(num1, num2 int) int {  
   /* 定义局部变量 */  
   var result int  
  
   if (num1 > num2) {  
      result = num1  
   } else {  
      result = num2  
   }  
   return result   
}
```
以上实例在 main() 函数中调用 max（）函数，执行结果为：
```
最大值是 : 200
```
###  <font color=#006666>三、函数参数</font>
值传递与指针传递，先看代码：
```
/* 值传递 */
```
