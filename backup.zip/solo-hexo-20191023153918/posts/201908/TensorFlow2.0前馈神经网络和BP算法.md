title: 《TensorFlow2.0》前馈神经网络和BP算法
date: '2019-08-26 14:21:44'
updated: '2019-08-30 11:34:50'
tags: [TensorFlow, python, 神经网络]
permalink: /articles/2019/08/26/1566800504453.html
---
![](https://img.hacpai.com/bing/20180710.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> <font color="red">**导读**</font>：什么是人工神经网络？人工神经网络有哪些分支？什么是前馈神经网络？神经网络如何使用反向传播？如何用keras搭建一个前馈神经网络架构？通过本篇文章，我们来解决以上问题。在阅读本篇文章之前，希望你已经了解感知器，SVM，成本函数，梯度优化。

### <font color="#006666">一、人工神经网络</font>
#### 1、人工神经网络主要分为两种类型：

* 前馈人工神经网络􏰍（Feedforward neural networks）􏰎，是最常用的神经网络类型􏰊，一般定义为有向无环图􏰋信号，只能沿着最终输入的那个方向传播。
* 􏰋另一种类型是反馈人工神经网络（􏰍feedback neural networks􏰎），也叫做递归神经网络，后面有一章专门介绍递归神经网络，本文只介绍<font color="red">前馈人工神经网络</font>。

#### 2、深度学习（Deep Learning）和神经网络（Neural Network）：

```
    Deep learning本身算是machine learning的一个分支，简单可以理解为neural network的发展。
```

```
    这里的neural network指的是传统神经网络，neural network曾经是ML领域特别火热的一个方向，但由于本身的一些缺点（过拟合，训练慢等），所以中间20多年时间，神经网络很少被关注。
```

```
    那段时间基本是SVM和boosting算法，后来Hinton和其他人一起提出了一个实际可行的deep learning框架，于是我们现在可以站在巨人的肩膀上。
```

```
    DL采用了神经网络相似的分层结构，但用了不同的训练机制，传统神经网络使用BP机制，DL整体上是一个layer-wise的训练机制。之所以这样做，是因为BP机制对于一个7层以上的network，残差传播到最前面的层已经变得太小，出现所谓的gradient diffusion（梯度扩散）。
```

```
    本篇文章介绍的前馈神经网络，属于传统神经网络，之所以写这遍文章，是想更深入的了解神经网络，及对keras使用的熟悉。对后面几篇介绍DL的文章，能更好的理解。
```


#### 3、XOR
让我们深入研究XOR异或（线性不可分函数）来感受一下人工神经网络的强大：
![xor.png](https://img.hacpai.com/file/2019/08/xor-1d6072a5.png)

```
􏰋AND是两个输入均为1，结果才为1
􏰊OR是两个 输入至少有1个1，结果即为1􏰋
XOR与它们不同􏰊，XOR是当两个输入中有且仅有1个1，结果才为1􏰋我们 
```

下面是XOR􏰊、OR、􏰊NAND和AND四种函数，有两个输入A和B时的输出真值表􏰋，从这个表我们可以检验OR、􏰊NAND和AND组合函数的输出，􏰊与同样输入的XOR输出相同:


| A | B |A AND B|A NAND B|A OR B|A XOR B|A OR B|A NAND B|(A OR B) AND (A NAND B)|
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | 0 | 0 | 1 | 0 | 0 | 0 | 1 | 0 | 
| 0 | 1 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 
| 1 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 
| 1 | 1 | 1 | 0 | 1 | 0 | 1 | 0 | 0 | 


<font color="red">**神经网络实现XOR：**</font>我们不使用单个感知器来表示XOR，􏰊而将建立一个具有多人工神经元的人工神经网络􏰊。每个神经元都近似一个线性函数􏰋，每个样本的特征表述都被输入到两个神经元􏰏，一个NAND神经元和一个OR神经元，􏰋这些神经元的输出将连接到第三个AND神经元上􏰊，测试XOR的条件是否为真􏰋。

### <font color="#006666">二、BP算法</font>
#### 1、多层感知器（MLP）
```
为了阐明反向传播的定义，让我们考虑一个与全连接的多层 MLP 相关联的特定图。多层感知器􏰍（multilayer perceptron）􏰊MLP􏰎是最流行的人工神经网络之一，􏰋它的名称不太恰当􏰊，多层感知器并非指单个带有多个层次的感知器，􏰊而是指可以是感知器的人工神经元组成的多个层次􏰋。MPL的层次结构是一个有向无环图􏰋。通常􏰊，每一层都全连接到下一层􏰊，某一层上的每个人工神经元的输出成为下一层若干人工神经元的输入，􏰋MLP至少有三层人工神经元􏰋。
```

#### 2、反向传播算法（BP）
```
反向传播􏰍BP􏰎算法经常用来连接优化算法求解成本函数最小化问题，􏰊比如梯度下降法，􏰋这个算法名称是反向（􏰍back）􏰎和传播􏰍（propagation）􏰎的合成词􏰊。是指误差在网络层的流向，􏰋理论上􏰊反向传播可以用于训练具有任意层􏰐、任意数量隐藏单元的前馈人工神经网络􏰊，但是计算能力的实际限制会约束反向传播的能力􏰋。
```

### <font color="#006666">三、神经网络设计</font>
#### 1、人工神经网络的三个组成部分􏰋：

* 第一个组成部分是架构􏰍（architecture）􏰎􏰊或称为拓扑结构（ 􏰍topology），􏰎􏰊描述神经元的层次与连接神经元的结构􏰋；
* 第二个组成部分是神经网络使用的激励函数；
* 第三个组成部分是找出最优权重值的学习算法􏰋。

#### 2、keras实现全连接的前馈神经网络：

```python
form tensorflow.keras.utils import plot_model
from tensorflow.keras import Model
from tensorflow.keras import layers

input_img1 = layers.Input(shape=(256,256,3))
input_img2 = layers .Input(shape=(256,256,3))

# 融合层 x = 3inp1+4inp2+5
input1 = layers.add([input_img1, input_img2])
第一层隐藏层
tower_1 = layers.Dense(10, activation='softmax')(input1)
tower_2 = layers.Dense(10, activation='softmax')(input1)
tower_3 = layers.Dense(10, activation='softmax')(input1)

# 融合层
input2 = layers.add([tower_1,tower_2,tower_3])
# 第二层隐藏层
tower_4 = layers.Dense(10, activation='softmax')(input2)
tower_5 = layers.Dense(10, activation='softmax')(input2)
tower_6 = layers.Dense(10, activation='softmax')(input2)
# 融合层
input3 = layers.add([tower_4,tower_5,tower_6])
# 输出层
output1 = layers.Dense(10, activation='softmax')(input3)
output2 = layers.Dense(10, activation='relu')(input3)

# 构建模型
model = Model(inputs=[input_img1, input_img2], outputs=[output1, output2])

# 展示模型架构
plot_model(model, 'multi_input_and_output_model.png', show_shapes=True)

```
`keras搭建的模型架构，可以看出和上面BP算法中的计算图一样`
![multiinputandoutputmodel.png](https://img.hacpai.com/file/2019/08/multiinputandoutputmodel-05526370.png)
