title: 《TensorFlow2.0》Keras高阶api入门（一）
date: '2019-08-04 23:04:28'
updated: '2019-08-11 22:05:16'
tags: [python, TensorFlow]
permalink: /articles/2019/08/04/1564931068743.html
---
![](https://img.hacpai.com/bing/20181215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


Keras 是一个用于构建和训练深度学习模型的高阶 API。它可用于快速设计原型、高级研究和生产，具有以下三个主要优势：

> * *方便用户使用*  
    `Keras 具有针对常见用例做出优化的简单而一致的界面。它可针对用户错误提供切实可行的清晰反馈。`
* *模块化和可组合*  
    `将可配置的构造块连接在一起就可以构建 Keras 模型，并且几乎不受限制。`
* *易于扩展*  
    `可以编写自定义构造块以表达新的研究创意，并且可以创建新层、损失函数并开发先进的模型。`

*<font color="red">**摘自**：Tensorflow2.0官方文档，更多Keras详细可查看[官方文档](https://keras.io/zh/)，本篇文章意在使读者对tf2.0中运行Keras有一个快速的认知，如果你已经很清楚了，可以跳过本篇</font>*

### <font color="#006666">一、Keras构建模型流程</font>
keras构建模型主要有两种方式：**序贯模型**和**函数式模型**，下面分别用这两个方法构建一个简单模型。
#### 1、序贯模型

`代码：`
```
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation
model = Sequential([Dense(32, activation='relu'),Dense(10, activation='softmax')])
model.compile(loss='binary_crossentropy',optimizer='rmsprop',metrics=['accuracy'])
import numpy as np
x_train = np.random.random((2000,30))
y_train = np.random.randint(3, size=(2000, 1))
x_val = np.random.random((200, 30))
y_val = np.random.randint(3, size=(200, 1))
model.fit(x_train, y_train,epochs=20,batch_size=128)
score = model.evaluate(x_val, y_val, batch_size=128)
print('val score:', score[0])
print('val accuracy:', score[1])
```
`输出：`
```
200/200 [==============================] - 0s 193us/sample - loss: 2.0829 - accuracy: 0.3950
val score: 2.082862229347229
val accuracy: 0.395
```
#### 2、函数式模型
`代码：`

```
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input,Dropout
inputs = Input(shape=(30,))
x=Dense(64,activation='relu')(inputs)
x=Dropout(0.5)(x)
x=Dense(64,activation='relu')(x)
x=Dropout(0.5)(x)
predictions=Dense(1, activation='sigmoid')(x)
model=Model(inputs=inputs, outputs=predictions)
model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy'])
model.fit(x_train, y_train,epochs=20,batch_size=128)
score = model.evaluate(x_val, y_val, batch_size=128)
print('val score:', score[0])
print('val accuracy:', score[1])
```
`输出：`
```
200/200 [==============================] - 0s 404us/sample - loss: 1.3313 - accuracy: 0.3100
val score: 1.3313488864898682
val accuracy: 0.31
```
函数时模型相对更灵活一些，具体开发中可以根据需求自定义激活函数，回调函数

### <font color="#006666">二、Keras中的网络层</font>



