title: 《python元编程》属性描述符
date: '2019-08-09 11:35:29'
updated: '2019-08-09 11:42:06'
tags: [python, python进阶]
permalink: /articles/2019/08/09/1565321729703.html
---
python属性描述符