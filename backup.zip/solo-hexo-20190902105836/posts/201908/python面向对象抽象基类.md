title: 《python面向对象》抽象基类
date: '2019-08-09 11:21:52'
updated: '2019-08-09 11:41:18'
tags: [python, python进阶]
permalink: /articles/2019/08/09/1565320912648.html
---
python抽象基类